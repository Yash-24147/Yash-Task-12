function fox(){
var p=Number(document.getElementById("principle").value);
var r=Number(document.getElementById("rate").value);
var t=Number(document.getElementById("time").value);
var n =Number(document.getElementById("monthly").value);
var a =p*(1+(r/n)**(n*t))
var y=document.getElementById("show").innerHTML="total amount is " +a.toFixed(2);
    console.log(y)
}
