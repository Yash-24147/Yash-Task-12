Compound Interest Calculator

About

This is a simple HTML and JavaScript project. I made this project to practice taking values from input fields and calculating compound interest using JavaScript.

The webpage contains input fields for principal, rate of interest, number of times interest is compounded per year, and time. A button is used to calculate and display the total amount.

Technologies Used

HTML5

JavaScript

Features

Added input field for principal amount

Added input field for rate of interest

Added input field for number of times interest is compounded per year

Added input field for time in years

Added a button to calculate the amount

Used JavaScript to perform the calculation

Displayed the calculated amount on the webpage

Used toFixed() to display the result up to 2 decimal places

Project Files

Compound-Interest-Calculator/

index.html

interest.js

style.css

README.md

JavaScript Used

Some basic JavaScript concepts used in this project are:

document.getElementById()

value property

Number() for converting input values into numbers

Arithmetic operators

Exponentiation operator

toFixed() for formatting the result

Formula

A = P x (1 + r/n)^(n x t)

Where

A = Amount

P = Principal

r = Rate of interest

n = Number of times interest is compounded per year

t = Time in years

How to Run

Keep index.html, interest.js and style.css in the same folder.

Open index.html in any browser.

Enter the principal amount, rate of interest, number of times interest is compounded per year, and time.

Click the Click button.

The calculated total amount will be displayed on the webpage.

Author

Yash
